﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Activation;

namespace Uwr.ASP.WCFDemos
{
    // NOTE: If you change the class name "DeclarativeService" here, you must also update the reference to "DeclarativeService" in Web.config.
    [ServiceContract]
    [ServiceBehavior( ConcurrencyMode=ConcurrencyMode.Multiple, InstanceContextMode=InstanceContextMode.PerCall )]
    [AspNetCompatibilityRequirements( RequirementsMode = AspNetCompatibilityRequirementsMode.Required )]
    public class DeclarativeService 
    {
        [OperationContract]
        public string DoWork( string Param )
        {
            return new string( Param.ToCharArray().Reverse().ToArray() );
        }
    }
}
