﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Activation;
using System.ServiceModel.Description;

namespace Uwr.ASP.WCFDemos
{
    // NOTE: If you change the class name "ImperativeService" here, you must also update the reference to "ImperativeService" in Web.config.
    [ServiceContract]
    [ServiceBehavior( ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.PerCall )]
    [AspNetCompatibilityRequirements( RequirementsMode = AspNetCompatibilityRequirementsMode.Required )]
    public class ImperativeService
    {
        [OperationContract]
        public string DoWork( string Param )
        {
            return new string( Param.ToCharArray().Reverse().ToArray() );
        }
    }

    public class ImperativeServiceFactory : ServiceHostFactory
    {
        protected virtual ServiceDebugBehavior ServiceDebug
        {
            get
            {
                ServiceDebugBehavior debug = new ServiceDebugBehavior();

                debug.IncludeExceptionDetailInFaults = true;
                debug.HttpHelpPageEnabled  = true;
                return debug;
            }
        }

        protected virtual ServiceMetadataBehavior ServiceMetadata
        {
            get
            {
                ServiceMetadataBehavior metadata = new ServiceMetadataBehavior();
                metadata.HttpGetEnabled = true;
                return metadata;
            }
        }

        public override ServiceHostBase CreateServiceHost( string constructorString, Uri[] baseAddresses )
        {
            ServiceHost serviceHost = new ServiceHost( typeof( ImperativeService ), baseAddresses );

            serviceHost.AddServiceEndpoint( typeof( ImperativeService ), new BasicHttpBinding(), baseAddresses[0] );

            // metadata  
            serviceHost.Description.Behaviors.Remove<ServiceMetadataBehavior>();
            serviceHost.Description.Behaviors.Add( this.ServiceMetadata );
            serviceHost.Description.Behaviors.Remove<ServiceDebugBehavior>();
            serviceHost.Description.Behaviors.Add( this.ServiceDebug );

            return serviceHost;
        }
    }

}
