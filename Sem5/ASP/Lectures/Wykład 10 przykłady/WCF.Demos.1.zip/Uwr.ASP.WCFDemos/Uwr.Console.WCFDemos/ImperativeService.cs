﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Uwr.Console.WCFDemos
{
    [ServiceContract]
    public class ImperativeService
    {
        [OperationContract]
        public string DoWork( string Param )
        {
            return new string( Param.ToCharArray().Reverse().ToArray() );
        }
    }
}
