﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace Uwr.Console.WCFDemos
{
    class Program
    {
        static void Main( string[] args )
        {
            Uri hostUri = new Uri( "http://localhost:12345/ImperativeService" );

            using ( ServiceHost host = new ServiceHost( typeof( ImperativeService ) ) )
            {
                ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
                smb.HttpGetEnabled = true;
                smb.HttpGetUrl = hostUri;
                host.Description.Behaviors.Add( smb );

                host.AddServiceEndpoint( typeof( ImperativeService ), new BasicHttpBinding(), hostUri );

                host.Open();

                System.Console.WriteLine( "service runs on " + hostUri.ToString() );

                System.Console.ReadLine();
            }
        }
    }
}
