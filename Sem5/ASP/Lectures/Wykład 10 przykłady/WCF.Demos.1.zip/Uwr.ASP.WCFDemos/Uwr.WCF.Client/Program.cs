﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace Uwr.WCF.Client
{
    class Program
    {
        static void Main( string[] args )
        {
            ExampleServiceReference.DeclarativeServiceClient client = new Uwr.WCF.Client.ExampleServiceReference.DeclarativeServiceClient();
            Console.WriteLine( client.DoWork( "qwerty" ) );
            Console.ReadLine();
        }
    }
}
