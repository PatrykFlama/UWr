﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using Interface;

namespace Service
{
    [ServiceBehavior( ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.PerCall )]
    public class TheImplementation : TheInterface
    {
        #region TheInterface Members

        public string DoWork( string Work )
        {
            return string.Format( "{0} from WCF!", Work );
        }

        #endregion
    }
}
