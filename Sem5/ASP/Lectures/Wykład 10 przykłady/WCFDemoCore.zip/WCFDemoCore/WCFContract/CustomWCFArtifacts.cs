﻿using System.Runtime.Serialization;
using System.ServiceModel;

namespace WCFContract
{
    /// <summary>
    /// Model dla żądania
    /// </summary>
    [DataContract]
    public class CustomRequestModel
    {
        [DataMember]
        public string RequestValue { get; set; }
    }

    /// <summary>
    /// Model dla odpowiedzi
    /// </summary>
    [DataContract]
    public class CustomResponseModel
    {
        [DataMember]
        public string ResponseValue { get; set; }
    }

    /// <summary>
    /// Interfejs usługi
    /// </summary>
    [ServiceContract]
    public interface ITestService
    {
        [OperationContract]
        CustomResponseModel DoWork( CustomRequestModel request );
    }
}
