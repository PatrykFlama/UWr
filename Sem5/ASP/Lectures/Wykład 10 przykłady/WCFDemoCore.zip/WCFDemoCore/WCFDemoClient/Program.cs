﻿using System.ServiceModel;
using WCFContract;

var address = new EndpointAddress("http://localhost:5194/TestService");
var binding = new BasicHttpBinding();

var client = new ChannelFactory<ITestService>( binding, address ).CreateChannel();
var response = client.DoWork(new CustomRequestModel() { RequestValue = "foo" });

Console.WriteLine( response.ResponseValue );

Console.ReadLine();

