using CoreWCF;
using CoreWCF.Configuration;
using CoreWCF.Description;
using WCFContract;
using WCFDemoCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddServiceModelServices().AddServiceModelMetadata();
//builder.Services.AddSingleton<IServiceBehavior, UseRequestHeadersForMetadataAddressBehavior>();

var app = builder.Build();

app.UseServiceModel( builder =>
{
    builder.AddService<TestServiceImpl>( ( serviceOptions ) => { } )
        .AddServiceEndpoint<TestServiceImpl, ITestService>( 
        new BasicHttpBinding(), "/TestService", endpoint =>
        {
            // tu mo�liwo�� rejestracji rozszerze�
            //endpoint.EndpointBehaviors.Add( ... );
        } );
} );

var serviceMetadataBehavior = app.Services.GetRequiredService<ServiceMetadataBehavior>();
serviceMetadataBehavior.HttpGetEnabled = true;

app.Run();
