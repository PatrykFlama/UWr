﻿using WCFContract;

namespace WCFDemoCore
{
    /// <summary>
    /// Implementacja usługi WCF
    /// </summary>
    public class TestServiceImpl : ITestService
    {
        public CustomResponseModel DoWork( CustomRequestModel request )
        {
            if ( request == null )
            {
                return new CustomResponseModel() { ResponseValue = "empty" };
            }
            else
            {
                return new CustomResponseModel()
                {
                    ResponseValue = request.RequestValue + " from WCF"
                };
            }
        }
    }
}
