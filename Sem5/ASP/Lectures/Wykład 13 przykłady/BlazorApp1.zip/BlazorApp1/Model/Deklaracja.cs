﻿namespace BlazorApp1.Model
{
    public class Deklaracja
    {
        const int LP = 10;

        public Deklaracja()
        {
            this.Punkty = new int[LP];
        }

        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public string Przedmiot { get; set; }
        public int[] Punkty { get; set; }
    }

    public enum WidokEnum
    {
        EDYCJA,
        WYDRUK
    }

}
