import React, { useState } from 'react';
import Deklaracja from './deklaracja';
import DeklaracjaEdytor from './deklaracja_edytor';
import DeklaracjaWydruk from './deklaracja_wydruk';

type Widok = 'EDYTOR' | 'WYDRUK';

// https://www.digitalocean.com/community/tutorials/7-ways-to-implement-conditional-rendering-in-react-applications

const App = () => {

  const [deklaracja, setDeklaracja] = useState<Deklaracja>(new Deklaracja());
  const [widok, setWidok] = useState<Widok>('EDYTOR');

  const deklaracjaHandler = (deklaracja: Deklaracja) => {
    setDeklaracja(deklaracja);
    setWidok("WYDRUK");
  }

  const wydrukHandler = () => {
    setWidok("EDYTOR");
  }

  return <>  
    {widok == 'EDYTOR' && <DeklaracjaEdytor {...deklaracja} handler={deklaracjaHandler}></DeklaracjaEdytor>}
    {widok == 'WYDRUK' && <DeklaracjaWydruk {...deklaracja} handler={wydrukHandler}></DeklaracjaWydruk>}
  </>
};

export default App;