class Deklaracja {

    readonly LP = 10;

    constructor() {
        this.punkty = new Array<number>(this.LP).fill(undefined);
    }

    imie: string;
    nazwisko: string;
    przedmiot: string;
    punkty: number[];
}

export default Deklaracja;