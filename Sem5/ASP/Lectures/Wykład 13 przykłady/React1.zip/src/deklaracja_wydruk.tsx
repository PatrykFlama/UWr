import React, { useState, FormEvent } from 'react';
import Deklaracja from './deklaracja';

const DeklaracjaWydruk = (deklaracja: Deklaracja & { handler: () => void }) => {

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();

        deklaracja.handler();
    }

    return <>
        <div>
            Imię: {deklaracja.imie}
        </div>
        <div>
            Nazwisko: {deklaracja.nazwisko}
        </div>
        <div>
            Przedmiot: {deklaracja.przedmiot}
        </div>
        {deklaracja.punkty.map( 
            (punkt, index) => { 
                return <div key={index}>
                    Zadanie {index+1}: {deklaracja.punkty[index]}
                </div> 
            } )}
        <div>
            <button onClick={handleSubmit}>Powrót</button>
        </div>
    </>;
}

export default DeklaracjaWydruk;