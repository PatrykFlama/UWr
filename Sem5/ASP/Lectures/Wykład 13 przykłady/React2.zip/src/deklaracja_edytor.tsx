import React, { useState, FormEvent, useRef, useEffect } from 'react';
import Deklaracja from './deklaracja';
import { useNavigate } from 'react-router';

const DeklaracjaEdytor = (deklaracja: Deklaracja & { handler: (deklaracja: Deklaracja) => void }) => {

    const [time, setTime] = useState(new Date());
    let navigate = useNavigate();

    useEffect( () => {
        const _interval = setInterval( () => {
            setTime( new Date() );
        }, 1000 )

        return () => {
            clearInterval( _interval );
        }
    }, []);

    const personEditHandler = (e: FormEvent) => {
        e.preventDefault();

        navigate( "/personEdit/1234" ); // wartość parametru tu jest stała ale może być odczytana dynamicznie
    }

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();

        const newDeklaracja = new Deklaracja();

        newDeklaracja.imie = imieRef.current.value;
        newDeklaracja.nazwisko = nazwiskoRef.current.value;
        newDeklaracja.przedmiot = przedmiotRef.current.value;

        newDeklaracja.punkty.forEach( (p,i) => {
            newDeklaracja.punkty[i] = punktyRef[i].current.value;
        });

        deklaracja.handler(newDeklaracja);
    }

    const imieRef = useRef(null);
    const nazwiskoRef = useRef(null);
    const przedmiotRef = useRef(null);
    const punktyRef = deklaracja.punkty.map( p => useRef(null));

    return <>
        <div>
            Bieżący czas: {time.toLocaleString()}
        </div>
        <div>
            Imię: <input placeholder='Imie' ref={imieRef} />
        </div>
        <div>
            Nazwisko: <input placeholder='Nazwisko' ref={nazwiskoRef} />
        </div>
        <div>
            Przedmiot: <input placeholder='Przedmiot' ref={przedmiotRef} />
        </div>
        {deklaracja.punkty.map( 
            (punkt, index) => { 
                return <div key={index}>
                    Zadanie {index+1}: <input defaultValue={deklaracja.punkty[index]} placeholder='0' ref={punktyRef[index]} />
                </div> 
            } )}
        <div>
            <button onClick={handleSubmit}>Akceptuj</button>
        </div>
        <div>
            <button onClick={personEditHandler}>Edycja danych osobowych</button>
        </div>
    </>;
}

export default DeklaracjaEdytor;