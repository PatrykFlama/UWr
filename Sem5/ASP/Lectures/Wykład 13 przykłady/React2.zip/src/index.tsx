import React from 'react';
import ReactDOM from 'react-dom';
import { createRoot } from "react-dom/client";
import { BrowserRouter, MemoryRouter, Routes, Route } from "react-router";

import App from '@/app';
import PersonEdit from './personEdit';

/**
 * Entry point
 */
class Program {
    
    Main() {

        /*
        var app = (
                <App />
        );

        ReactDOM.render(app, document.getElementById('root'));
        */

        const root = createRoot(document.getElementById("root") as HTMLElement);        
        // BrowserRouter vs MemoryRouter
        root.render(
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<App />} />
                    <Route path="/personEdit/:id" element={<PersonEdit />} />
                </Routes>            
            </BrowserRouter>
        );
    }
}

new Program().Main();