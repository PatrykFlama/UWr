import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router';

const PersonEdit = () => {

    const [personId, setPersonId] = useState('');
    const [personData, setPersonData] = useState<string>(null);
    let { id } = useParams();

    useEffect( () => {
        setPersonId( id );

        const loadData = async () => {
            setTimeout( () => {
                setPersonData("dane załadowane z serwera");
            }, 2000);
        };

        loadData();
    }, []);

    return <>
        <div>
            Edycja danych osobowych: {personId}
        </div>
        {!personData && <div>
            Trwa ładowanie danych
        </div>}
        {personData && <div>
            {personData}
        </div>}        
    </>

}

export default PersonEdit;