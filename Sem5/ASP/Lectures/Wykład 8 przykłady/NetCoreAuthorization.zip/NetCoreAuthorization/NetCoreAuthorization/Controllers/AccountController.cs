﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using NetCoreAuthorization.Models;
using System.Security.Claims;

namespace NetCoreAuthorization.Controllers
{
    public class AccountController : Controller
    {
        [HttpGet]
        public IActionResult Logon()
        {
            var model = new LogonModel();
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Logon(LogonModel model)
        {
            if ( this.ModelState.IsValid )
            {
                if ( !string.IsNullOrEmpty( model.UserName ) && model.UserName == model.Password )
                {
                    List<Claim> claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, model.UserName),
                        new Claim(ClaimTypes.Role, model.UserName),
                        new Claim(ClaimTypes.DateOfBirth, new DateTime(1990, 1, 1).ToString())
                    };

                    // create identity
                    ClaimsIdentity identity   = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    ClaimsPrincipal principal = new ClaimsPrincipal(identity);

                    await this.HttpContext.SignInAsync( CookieAuthenticationDefaults.AuthenticationScheme, principal );

                    return Redirect( "/" );

                }
                else
                {
                    this.ViewBag.Message = "Zła nazwa użytkownika lub hasło";
                }
            }

            return View( model );
        }
    }
}
