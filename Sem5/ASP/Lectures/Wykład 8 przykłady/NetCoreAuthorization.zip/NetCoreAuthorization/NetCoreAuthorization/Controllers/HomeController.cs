﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Security.Claims;

namespace NetCoreAuthorization.Controllers
{
    [Authorize()]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return Content( $"Zalogowany jako {this.User.Identity.Name}" );
        }

        [Authorize( Roles = "admin")]
        public IActionResult Admin()
        {
            return Content( $"Zalogowany admin jako {this.User.Identity.Name}" );
        }

        [CustomAuthorize("foo")]
        public IActionResult CustomAuthorize()
        {
            return Content( $"CustomAuthorize jako {this.User.Identity.Name}" );
        }

        [Authorize( Policy = "Over18")]
        public IActionResult Over18()
        {
            return Content( $"Over18 jako {this.User.Identity.Name}" );
        }
    }

    [AttributeUsage( AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true, Inherited = true )]
    public class CustomAuthorizeAttribute : AuthorizeAttribute, IAuthorizationFilter
    {
        private readonly string _userName;

        public CustomAuthorizeAttribute( string userName )
        {
            _userName = userName;
        }

        public void OnAuthorization( AuthorizationFilterContext context )
        {
            var user = context.HttpContext.User;

            if ( !user.Identity.IsAuthenticated )
            {
                // it isn't needed to set unauthorized result 
                // as the base class already requires the user to be authenticated
                // this also makes redirect to a login page work properly
                // context.Result = new UnauthorizedResult();
                return;
            }

            var isAuthorized = context.HttpContext.User.Identity.Name == this._userName;
            if ( !isAuthorized )
            {
                context.Result = new StatusCodeResult( (int)System.Net.HttpStatusCode.Forbidden );
                return;
            }
        }
    }

}
