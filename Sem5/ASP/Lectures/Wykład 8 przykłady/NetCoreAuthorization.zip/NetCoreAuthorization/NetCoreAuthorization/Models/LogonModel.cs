﻿using System.ComponentModel.DataAnnotations;

namespace NetCoreAuthorization.Models
{
    public class LogonModel
    {
        [Required]
        public string UserName { get; set; }

        [Required]
        public string Password { get; set; }
    }
}
