using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();

builder.Services
    .AddAuthentication( CookieAuthenticationDefaults.AuthenticationScheme )
    .AddCookie( CookieAuthenticationDefaults.AuthenticationScheme, options =>
    {
        options.LoginPath = "/Account/Logon";
        // options.AccessDeniedPath = ""; �cie�ka przekierowania dla braku uprawnienia
        options.SlidingExpiration = true;
    } );

builder.Services
    .AddAuthorization( options =>
    {
        options.AddPolicy("Over18",
            policy => policy.Requirements.Add( new MinimumAgeRequirement( 18 ) ) );
    } );
builder.Services.AddSingleton<IAuthorizationHandler, MinimumAgeHandler>();


var app = builder.Build();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.UseEndpoints( e =>
{
    e.MapControllerRoute(
                        name: "default",
                        pattern: "{controller=Home}/{action=Index}/{id?}" );
} );

app.Run();

public class MinimumAgeRequirement : IAuthorizationRequirement
{
    public MinimumAgeRequirement( int minimumAge ) =>
        MinimumAge = minimumAge;

    public int MinimumAge { get; }
}

public class MinimumAgeHandler : AuthorizationHandler<MinimumAgeRequirement>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context, MinimumAgeRequirement requirement )
    {
        var dateOfBirthClaim = context.User.FindFirst( c => c.Type == ClaimTypes.DateOfBirth);

        if ( dateOfBirthClaim is null )
        {
            return Task.CompletedTask;
        }

        var dateOfBirth = Convert.ToDateTime(dateOfBirthClaim.Value);
        int calculatedAge = DateTime.Today.Year - dateOfBirth.Year;
        if ( dateOfBirth > DateTime.Today.AddYears( -calculatedAge ) )
        {
            calculatedAge--;
        }

        if ( calculatedAge >= requirement.MinimumAge )
        {
            context.Succeed( requirement );
        }

        return Task.CompletedTask;
    }
}