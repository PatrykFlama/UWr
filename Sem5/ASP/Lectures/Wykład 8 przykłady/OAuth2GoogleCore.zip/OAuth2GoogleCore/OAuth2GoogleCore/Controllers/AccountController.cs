﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OAuth2GoogleCore.Models;
using System.Reflection;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.Google;

namespace OAuth2GoogleCore.Controllers
{
    
    public class AccountController : Controller
    {
        public AccountController()
        {
        }

        [HttpGet]
        public async Task<IActionResult> Logon(string returnUrl)
        {
            var model = new LogonModel()
            {
                ReturnUrl = returnUrl
            };

            return View( model );
        }

        [HttpPost]
        public IActionResult Logon( string provider, string returnUrl )
        {
            return this.Challenge( new AuthenticationProperties()
            {
                RedirectUri = Url.Action( "GoogleResponse" )
            }, GoogleDefaults.AuthenticationScheme );
        }

        public async Task<IActionResult>
            GoogleResponse( string returnUrl = null, string remoteError = null )
        {
            var result = await HttpContext.AuthenticateAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            var claims = result.Principal.Identities
                .FirstOrDefault().Claims.Select(claim => new
                {
                    claim.Issuer,
                    claim.OriginalIssuer,
                    claim.Type,
                    claim.Value
                });
            return Redirect( "/" );
        }
    }
}
