﻿using Microsoft.AspNetCore.Authentication;

namespace OAuth2GoogleCore.Models
{
    public class LogonModel
    {
        public string ReturnUrl { get; set; }
    }
}
