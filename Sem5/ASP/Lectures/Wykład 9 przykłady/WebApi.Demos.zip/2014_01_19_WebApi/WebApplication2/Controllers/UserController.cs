﻿using SharedModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebApplication2.Controllers
{
    public class UserController : ApiController
    {
        public List<UserDTO> GetAll()
        {
            return new List<UserDTO>()
            {
                new UserDTO() { Name = "foo1", Surname = "foo1s" },
                new UserDTO() { Name = "bar1", Surname = "bar1s" },
            };
        }

        public HttpResponseMessage PostUser(UserDTO user)
        {
            Console.WriteLine(user.Name);
            Console.WriteLine(user.Surname);
            return this.Request.CreateResponse<string>(System.Net.HttpStatusCode.OK, "zapisano");
        }
    }
}
